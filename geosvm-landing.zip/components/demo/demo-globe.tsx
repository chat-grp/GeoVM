"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { useGlobeStore } from "@/lib/demo/globe-store"
import { useNotification } from "@/components/demo/notification-provider"
import { getTrixelId, getParentTrixelId, latLngToVector3, getTrixelVertices } from "@/lib/demo/globe-utils"
import { TrixelUpdateAnimation } from "@/components/demo/trixel-update-animation"

export function DemoGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { addNotification } = useNotification()
  const {
    incrementActivity,
    setActiveNode,
    activeNode,
    zoomLevel,
    setZoomLevel,
    addActiveTrixel,
    clearActiveTrixels,
    activeTrixels,
  } = useGlobeStore()

  const [showUpdateAnimation, setShowUpdateAnimation] = useState(false)
  const [updateTrixelPath, setUpdateTrixelPath] = useState<string[]>([])

  // Handle globe click
  const handleGlobeClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return

    const rect = canvasRef.current.getBoundingClientRect()
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1
    const y = -((event.clientY - rect.top) / rect.height) * 2 + 1

    // Convert to lat/lng (simplified for demo)
    const lat = y * 90
    const lng = x * 180

    // Set active node
    setActiveNode({ lat, lng })

    // Increment activity counter
    incrementActivity()

    // Show notification
    addNotification("Simulated Activity Recorded", "success")

    // Zoom in
    setZoomLevel(3)

    // Generate trixel path for update animation
    const baseTrixelId = getTrixelId(lat, lng, 3)
    const level2TrixelId = getParentTrixelId(baseTrixelId)
    const level1TrixelId = getParentTrixelId(level2TrixelId)

    // Set trixel path and trigger animation
    setUpdateTrixelPath([baseTrixelId, level2TrixelId, level1TrixelId])
    clearActiveTrixels()

    // Start animation sequence
    setTimeout(() => {
      setShowUpdateAnimation(true)
      addActiveTrixel(baseTrixelId)

      setTimeout(() => {
        addActiveTrixel(level2TrixelId)

        setTimeout(() => {
          addActiveTrixel(level1TrixelId)

          // Reset after animation completes
          setTimeout(() => {
            setShowUpdateAnimation(false)
            setZoomLevel(1)
            setActiveNode(null)
          }, 2000)
        }, 1000)
      }, 1000)
    }, 500)
  }

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const setCanvasDimensions = () => {
      const container = canvas.parentElement
      if (container) {
        canvas.width = container.clientWidth
        canvas.height = container.clientHeight
      }
    }

    setCanvasDimensions()
    window.addEventListener("resize", setCanvasDimensions)

    // Animation variables
    let animationFrame: number
    let rotation = 0
    const rotationSpeed = 0.001

    // Draw the globe
    const drawGlobe = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      const centerX = canvas.width / 2
      const centerY = canvas.height / 2
      const radius = Math.min(centerX, centerY) * 0.8 * zoomLevel

      // Draw globe
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(200, 240, 255, 0.2)"
      ctx.fill()
      ctx.strokeStyle = "rgba(0, 150, 200, 0.5)"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw grid lines (simplified HTM representation)
      ctx.strokeStyle = "rgba(0, 180, 220, 0.7)"
      ctx.lineWidth = 1

      // Draw meridians
      for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * Math.PI * 2 + rotation

        // Rotate context for meridian
        ctx.save()
        ctx.translate(centerX, centerY)
        ctx.rotate(angle)
        ctx.beginPath()
        ctx.moveTo(0, -radius)
        ctx.lineTo(0, radius)
        ctx.stroke()
        ctx.restore()
      }

      // Draw parallels
      for (let j = 1; j < 6; j++) {
        const parallelRadius = (j / 6) * radius
        ctx.beginPath()
        ctx.arc(centerX, centerY, parallelRadius, 0, Math.PI * 2)
        ctx.stroke()
      }

      // Draw triangular mesh (simplified)
      ctx.strokeStyle = "rgba(0, 200, 150, 0.8)"
      ctx.lineWidth = 1.5

      const drawTriangle = (x1: number, y1: number, x2: number, y2: number, x3: number, y3: number) => {
        ctx.beginPath()
        ctx.moveTo(x1, y1)
        ctx.lineTo(x2, y2)
        ctx.lineTo(x3, y3)
        ctx.closePath()
        ctx.stroke()
      }

      // Draw some sample triangles
      for (let k = 0; k < 8; k++) {
        const angle1 = (k / 8) * Math.PI * 2 + rotation
        const angle2 = ((k + 1) / 8) * Math.PI * 2 + rotation

        const x1 = centerX
        const y1 = centerY
        const x2 = centerX + Math.cos(angle1) * radius
        const y2 = centerY + Math.sin(angle1) * radius
        const x3 = centerX + Math.cos(angle2) * radius
        const y3 = centerY + Math.sin(angle2) * radius

        drawTriangle(x1, y1, x2, y2, x3, y3)

        // Draw subdivision (level 1)
        const midX1 = (x1 + x2) / 2
        const midY1 = (y1 + y2) / 2
        const midX2 = (x2 + x3) / 2
        const midY2 = (y2 + y3) / 2
        const midX3 = (x3 + x1) / 2
        const midY3 = (y3 + y1) / 2

        drawTriangle(midX1, midY1, midX2, midY2, midX3, midY3)
      }

      // Draw active node if exists
      if (activeNode) {
        const vector = latLngToVector3(activeNode.lat, activeNode.lng, radius)

        // Convert 3D coordinates to 2D screen coordinates (simplified)
        const nodeX = centerX + vector.x
        const nodeY = centerY - vector.y

        // Draw ripple effect
        ctx.beginPath()
        ctx.arc(nodeX, nodeY, 10 + Math.sin(Date.now() * 0.01) * 5, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(0, 220, 180, 0.3)"
        ctx.fill()

        // Draw point
        ctx.beginPath()
        ctx.arc(nodeX, nodeY, 4, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(0, 220, 180, 1)"
        ctx.fill()

        // Draw trixel around the point
        const vertices = getTrixelVertices(activeNode.lat, activeNode.lng, radius, 20)

        if (vertices.length >= 3) {
          ctx.beginPath()
          ctx.moveTo(centerX + vertices[0].x, centerY - vertices[0].y)

          for (let i = 1; i < vertices.length; i++) {
            ctx.lineTo(centerX + vertices[i].x, centerY - vertices[i].y)
          }

          ctx.closePath()
          ctx.fillStyle = "rgba(0, 220, 180, 0.2)"
          ctx.fill()
          ctx.strokeStyle = "rgba(0, 220, 180, 0.8)"
          ctx.lineWidth = 2
          ctx.stroke()
        }
      }

      // Highlight active trixels
      activeTrixels.forEach((trixelId, index) => {
        // This is a simplified visualization
        const level = Number.parseInt(trixelId.split("-")[1])
        const size = 30 / level

        ctx.save()
        ctx.translate(centerX, centerY)
        ctx.rotate(rotation + index * 0.5)

        ctx.beginPath()
        ctx.moveTo(0, 0)
        ctx.lineTo(size, -size * 1.5)
        ctx.lineTo(-size, -size * 1.5)
        ctx.closePath()

        ctx.fillStyle = `rgba(0, 220, 180, ${0.3 / level})`
        ctx.fill()
        ctx.strokeStyle = `rgba(0, 220, 180, ${0.8 / level})`
        ctx.lineWidth = 2
        ctx.stroke()

        ctx.restore()
      })

      // Animate rotation if not zoomed in
      if (zoomLevel === 1) {
        rotation += rotationSpeed
      }

      animationFrame = requestAnimationFrame(drawGlobe)
    }

    drawGlobe()

    return () => {
      window.removeEventListener("resize", setCanvasDimensions)
      cancelAnimationFrame(animationFrame)
    }
  }, [activeNode, zoomLevel, activeTrixels])

  return (
    <Card className="border-2 border-gray-100 dark:border-gray-800 relative overflow-hidden">
      <CardContent className="p-0">
        <div className="relative h-[600px] w-full bg-gradient-to-br from-gray-50 to-blue-50 dark:from-gray-900 dark:to-blue-950/30">
          <canvas ref={canvasRef} className="h-full w-full cursor-pointer" onClick={handleGlobeClick} />

          {showUpdateAnimation && (
            <div className="absolute inset-0 pointer-events-none">
              <TrixelUpdateAnimation trixelPath={updateTrixelPath} />
            </div>
          )}

          <div className="absolute bottom-4 left-4 bg-white/80 dark:bg-gray-900/80 rounded-lg p-2 text-xs text-gray-500 dark:text-gray-400 backdrop-blur-sm">
            Click anywhere on the globe to simulate DePIN activity
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
